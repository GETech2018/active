﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let Button_1 = ''
        let Button_Switch_BG_Color = ''

        let bgColorIndex = 0;
        let bgColorList = [0xFF000000, 0xFF804000, 0xFF004000, 0xFF004080, 0xFF000040, 0xFF800040, 0xFF400040, 0xFFFF80C0, 0xFF804040, 0xFF804000, 0xFF808080, 0xFF8080C0];
        let bgColorToastList = ['Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //start of ignored block
            console.log('SwitchBG_Color');
            function switchBG_Color() {
              bgColorIndex++;
              if (bgColorIndex >= bgColorList.length) bgColorIndex = 0;
              hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
              let toastText = bgColorToastList[bgColorIndex].replace('%s', `${bgColorIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
              vibro(28);
            };
            //end of ignored block

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hora.png',
              hour_centerX: 196,
              hour_centerY: 224,
              hour_posX: 14,
              hour_posY: 131,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minuto.png',
              minute_centerX: 196,
              minute_centerY: 224,
              minute_posX: 15,
              minute_posY: 180,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'segundo.png',
              second_centerX: 196,
              second_centerY: 224,
              second_posX: 6,
              second_posY: -19,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hora.png',
              hour_centerX: 196,
              hour_centerY: 224,
              hour_posX: 14,
              hour_posY: 131,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minuto.png',
              minute_centerX: 196,
              minute_centerY: 224,
              minute_posX: 15,
              minute_posY: 180,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'segundo.png',
              second_centerX: 196,
              second_centerY: 224,
              second_posX: 6,
              second_posY: -19,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 141,
              y: 402,
              w: 112,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'alexa.png',
              normal_src: 'alexa.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1, url: 'OnlineVADScreen', native: true })
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBG_Color');
            // Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.SwitchBG_Color, {
              // x: 162,
              // y: 194,
              // w: 69,
              // h: 62,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: 'pontotransparente.png',
              // normal_src: 'pontotransparente.png',
              // color_list: 0xFF000000|0xFF804000|0xFF004000|0xFF004080|0xFF000040|0xFF800040|0xFF400040|0xFFFF80C0|0xFF804040|0xFF804000|0xFF808080|0xFF8080C0,
              // toast_list: Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s|Background %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: True,
            // });

            Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 162,
              y: 194,
              w: 69,
              h: 62,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'pontotransparente.png',
              normal_src: 'pontotransparente.png',
              click_func: (button_widget) => {
                switchBG_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            // vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                //SwitchBgColor
                if (hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`) === undefined) {
                  bgColorIndex = 0;
                  hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
                } else {
                  bgColorIndex = hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg) normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}