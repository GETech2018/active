/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v2.1.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_img3 = '';
		let normal_img4 = '';
		let normal_img5 = '';
		let normal_img6 = '';
		let normal_img7 = '';
		let normal_img8 = '';
		let normal_img9 = '';
		let normal_img10 = '';
		let normal_img11 = '';
		let normal_img12 = '';
		let normal_hour_imagecombo14 = '';
		let normal_minute_imagecombo15 = '';
		let normal_img16 = '';
		let normal_heart_current_imagecombo18 = '';
		let normal_steps_imagecombo20 = '';
		let normal_calories_imagecombo22 = '';
		let normal_stress_imagecombo24 = '';
		let normal_temperature_body_imagecombo26 = new Array(3);
		let normal_temperature_body_imagecombo26_padding = false;
		let normal_temperature_body_imagecombo26_array = ['0052.png','0053.png','0054.png','0055.png','0056.png','0057.png','0058.png','0059.png','0060.png','0061.png','0062.png','0063.png','0062.png'];
		let normal_img27 = '';
		let normal_blood_oxygen_imagecombo29 = '';
		let normal_battery_imagecombo31 = '';
		let normal_weather_imageset33 = '';
		let normal_temperature_current_imagecombo34 = '';
		let normal_current_city_text35 = '';
		let normal_bt_status37 = '';
		let normal_alarm_status38 = '';
		let normal_dnd_status39 = '';
		let normal_lock_status40 = '';
		let normal_date_imagecombo42 = '';
		let normal_month_imageset43 = '';
		let normal_week_imageset44 = '';
		let normal_moon_phase30_imageset45 = '';
		let normal_fourseasons_imageset46 = '';
		let normal_fourseasons_imageset46_array = ['0176.png','0177.png','0178.png','0179.png'];
		let normal_user_region_text48 = '';
		let normal_user_nickname_text49 = '';
		let normal_heart_shortcut52 = '';
		let normal_bodytemp_shortcut53 = '';
		let normal_calories_shortcut54 = '';
		let normal_spo2_shortcut55 = '';
		let normal_flashlight56 = '';
		let screen_brightness = 0;
		let normal_todo_shortcut57 = '';
		let normal_activities_shortcut58 = '';
		let normal_battery_shortcut59 = '';
		let normal_countdown_shortcut60 = '';
		let normal_stopwatch_shortcut61 = '';
		let normal_weather_shortcut62 = '';
		let normal_calendar_shortcut63 = '';
		let normal_settings_shortcut64 = '';
		let normal_alarm_shortcut65 = '';
		let normal_sun_shortcut66 = '';
		let normal_stress_shortcut67 = '';
		let normal_steps_shortcut68 = '';
		let idle_hour_imagecombo70 = '';
		let idle_minute_imagecombo71 = '';
		let idle_img72 = '';
		let idle_battery_imagecombo74 = '';
		let idle_bt_status76 = '';
		let idle_alarm_status77 = '';
		let idle_dnd_status78 = '';
		let idle_lock_status79 = '';
		let normal_flashlight_foreground = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
				const body_tempSensor = hmSensor.createSensor(hmSensor.id.BODY_TEMP);
				const vibrateSensor = hmSensor.createSensor(hmSensor.id.VIBRATE);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 15,
					y: 271,
					w: 102,
					h: 61,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 143,
					y: 271,
					w: 102,
					h: 61,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 270,
					y: 271,
					w: 102,
					h: 61,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 270,
					y: 346,
					w: 102,
					h: 61,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 143,
					y: 346,
					w: 102,
					h: 61,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 15,
					y: 346,
					w: 102,
					h: 61,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 42,
					y: 275,
					w: 49,
					h: 22,
					src: '0004.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 168,
					y: 275,
					w: 45,
					h: 22,
					src: '0005.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img9 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 286,
					y: 275,
					w: 71,
					h: 22,
					src: '0006.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 39,
					y: 349,
					w: 56,
					h: 22,
					src: '0007.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 160,
					y: 349,
					w: 68,
					h: 22,
					src: '0008.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 297,
					y: 349,
					w: 48,
					h: 22,
					src: '0009.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo14 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 14,
					hour_startY: 145,
					hour_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo15 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 228,
					minute_startY: 145,
					minute_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img16 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 170,
					y: 115,
					w: 43,
					h: 152,
					src: '0020.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo18 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 41,
					y: 301,
					font_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
					padding: false,
					h_space: 0,
					invalid_image: '0031.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo20 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 150,
					y: 301,
					font_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo22 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 286,
					y: 301,
					font_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_imagecombo24 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 43,
					y: 375,
					font_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				for (let i = 0; i < normal_temperature_body_imagecombo26.length; i++) {
					normal_temperature_body_imagecombo26[i] = hmUI.createWidget(hmUI.widget.IMG, {
						x: 154 + i * 25,
						y: 369,
						w: 25,
						h: 39,
						enable: false,
						show_level: hmUI.show_level.ONLY_NORMAL,
					})

				}

				normal_img27 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 196,
					y: 366,
					w: 17,
					h: 45,
					src: '0064.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_blood_oxygen_imagecombo29 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 295,
					y: 374,
					font_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.SPO2,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imagecombo31 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 162,
					y: 425,
					font_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png"],
					padding: false,
					h_space: 0,
					unit_sc: '0075.png',
					unit_tc: '0075.png',
					unit_en: '0075.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset33 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 36,
					y: 66,
					image_array: ["0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0078.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0076.png","0077.png","0079.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo34 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 39,
					y: 43,
					font_array: ["0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0112.png"],
					unit_tc: ["0112.png"],
					unit_en: ["0112.png"],
					negative_image: ["0111.png"],
					invalid_image: ["0111.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_current_city_text35 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 144,
					y: 5,
					w: 100,
					h: 25,
					color: 0xFF6600,
					text: '--',
					text_size: 25,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_bt_status37 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 311,
					y: 5,
					w: 25,
					h: 25,
					type: hmUI.system_status.DISCONNECT,
					src: '0113.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_status38 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 59,
					y: 4,
					w: 23,
					h: 24,
					type: hmUI.system_status.CLOCK,
					src: '0114.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_dnd_status39 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 283,
					y: 7,
					w: 25,
					h: 20,
					type: hmUI.system_status.DISTURB,
					src: '0115.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_lock_status40 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 86,
					y: 2,
					w: 25,
					h: 25,
					type: hmUI.system_status.LOCK,
					src: '0116.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo42 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 149,
					day_startY: 33,
					day_sc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					day_tc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					day_en_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset43 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 149,
					month_startY: 78,
					month_sc_array: ["0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png"],
					month_tc_array: ["0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png"],
					month_en_array: ["0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset44 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 171,
					y: 109,
					week_en: ["0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
					week_tc: ["0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
					week_sc: ["0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_moon_phase30_imageset45 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 277,
					y: 44,
					image_array: ["0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png","0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png"],
					image_length: 30,
					type: hmUI.data_type.MOON,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_fourseasons_imageset46 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 273,
					y: 110,
					w: 273,
					h: 110,
					src: '0179.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_user_region_text48 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 232,
					y: 428,
					w: 100,
					h: 20,
					color: 0xFF6600,
					text_size: 20,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_user_nickname_text49 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 42,
					y: 428,
					w: 100,
					h: 20,
					color: 0xFF6600,
					text_size: 20,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_shortcut52 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 14,
					y: 267,
					w: 100,
					h: 70,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_bodytemp_shortcut53 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 147,
					y: 347,
					w: 100,
					h: 65,
					src: '',
					type: hmUI.data_type.BODY_TEMP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_shortcut54 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 272,
					y: 264,
					w: 100,
					h: 70,
					src: '',
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_spo2_shortcut55 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 270,
					y: 342,
					w: 100,
					h: 70,
					src: '',
					type: hmUI.data_type.SPO2,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_flashlight56 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 274,
					y: 37,
					w: 70,
					h: 70,
					src: '',
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				normal_flashlight56.addEventListener(hmUI.event.CLICK_UP, (info) => {
					screen_brightness = hmSetting.getBrightness();
					hmSetting.setBrightness(100);
					normal_flashlight_foreground.setProperty(hmUI.prop.VISIBLE, true);
					hmUI.showToast({
						text: 'ярлык Фонарик Вкл'
					});
					vibrateSensor.stop();
					vibrateSensor.scene = 25;
					vibrateSensor.start();
				});

				normal_todo_shortcut57 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 243,
					y: 421,
					w: 100,
					h: 30,
					text: '',
					normal_src: '',
					press_src: '',
					click_func: () => {
						hmApp.startApp({ url: 'todoListScreen', native: true });
					},
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_activities_shortcut58 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 34,
					y: 420,
					w: 100,
					h: 30,
					text: '',
					normal_src: '',
					press_src: '',
					click_func: () => {
						hmApp.startApp({ url: 'SportListScreen', native: true });
					},
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_shortcut59 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 163,
					y: 418,
					w: 50,
					h: 32,
					src: '',
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_countdown_shortcut60 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 36,
					y: 142,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.COUNT_DOWN,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stopwatch_shortcut61 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 249,
					y: 139,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.STOP_WATCH,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_shortcut62 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 22,
					y: 35,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calendar_shortcut63 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 143,
					y: 40,
					w: 100,
					h: 100,
					text: '',
					normal_src: '',
					press_src: '',
					click_func: () => {
						hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
					},
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_settings_shortcut64 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 139,
					y: 0,
					w: 100,
					h: 30,
					text: '',
					normal_src: '',
					press_src: '',
					click_func: () => {
						hmApp.startApp({ url: 'Settings_homeScreen', native: true });
					},
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_shortcut65 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 58,
					y: 4,
					w: 59,
					h: 30,
					src: '',
					type: hmUI.data_type.ALARM_CLOCK,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sun_shortcut66 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 265,
					y: 108,
					w: 100,
					h: 30,
					src: '',
					type: hmUI.data_type.SUN_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_shortcut67 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 15,
					y: 345,
					w: 100,
					h: 70,
					src: '',
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_shortcut68 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 146,
					y: 263,
					w: 100,
					h: 70,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_hour_imagecombo70 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 14,
					hour_startY: 145,
					hour_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo71 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 228,
					minute_startY: 145,
					minute_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img72 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 170,
					y: 115,
					w: 43,
					h: 152,
					src: '0020.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_battery_imagecombo74 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 162,
					y: 425,
					font_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png"],
					padding: false,
					h_space: 0,
					unit_sc: '0075.png',
					unit_tc: '0075.png',
					unit_en: '0075.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_bt_status76 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 311,
					y: 5,
					w: 25,
					h: 25,
					type: hmUI.system_status.DISCONNECT,
					src: '0113.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_alarm_status77 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 59,
					y: 4,
					w: 23,
					h: 24,
					type: hmUI.system_status.CLOCK,
					src: '0114.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_dnd_status78 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 283,
					y: 7,
					w: 25,
					h: 20,
					type: hmUI.system_status.DISTURB,
					src: '0115.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_lock_status79 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 86,
					y: 2,
					w: 25,
					h: 25,
					type: hmUI.system_status.LOCK,
					src: '0116.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				normal_flashlight_foreground = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 390,
					h: 450,
					src: '0180.png',
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				normal_flashlight_foreground.setProperty(hmUI.prop.VISIBLE, false);

				normal_flashlight_foreground.addEventListener(hmUI.event.CLICK_DOWN, (info) => {
					hmSetting.setBrightness(screen_brightness);
					normal_flashlight_foreground.setProperty(hmUI.prop.VISIBLE, false);
					hmUI.showToast({
						text: 'ярлык Фонарик Выкл'
					});
					vibrateSensor.stop();
					vibrateSensor.scene = 25;
					vibrateSensor.start();
				});

				function updateTime() {
					let day = timeSensor.day;
					let month = timeSensor.month-1;
					let season = 0;
					switch (month) {
						case 2:
							if (day >= 1 && day <= 19) {
								season = 3;
							} else if (day >= 20 && day <= 31) {
								season = 0;
							}
							break;
						case 3:
							if (day >= 1 && day <= 30) {
								season = 0;
							}
							break;
						case 4:
							if (day >= 1 && day <= 31) {
								season = 0;
							}
							break;
						case 5:
							if (day >= 1 && day <= 20) {
								season = 0;
							} else if (day >= 21 && day <= 30) {
								season = 1;
							}
							break;
						case 6:
							if (day >= 1 && day <= 31) {
								season = 1;
							}
							break;
						case 7:
							if (day >= 1 && day <= 31) {
								season = 1;
							}
							break;
						case 8:
							if (day >= 1 && day <= 21) {
								season = 1;
							} else if (day >= 22 && day <= 30) {
								season = 2;
							}
							break;
						case 9:
							if (day >= 1 && day <= 31) {
								season = 2;
							}
							break;
						case 10:
							if (day >= 1 && day <= 30) {
								season = 2;
							}
							break;
						case 11:
							if (day >= 1 && day <= 21) {
								season = 2;
							} else if (day >= 22 && day <= 31) {
								season = 3;
							}
							break;
						case 0:
							if (day >= 1 && day <= 31) {
							season = 3;
							}
							break;
						case 1:
							if (day >= 1 && day <= 29) {
								season = 3;
							}
							break;
					};
					normal_fourseasons_imageset46.setProperty(hmUI.prop.MORE, {
						src: normal_fourseasons_imageset46_array[season]
					})
				}

				function updateWeather() {
					normal_current_city_text35.setProperty(hmUI.prop.TEXT, weatherSensor.getForecastWeather().cityName);
				}

				function updateBodyTemp() {
					let normal_temperature_body_imagecombo26_current = body_tempSensor.current;
					if (normal_temperature_body_imagecombo26_padding) {
						normal_temperature_body_imagecombo26_current = normal_temperature_body_imagecombo26_current.toString().padStart(normal_temperature_body_imagecombo26.length, '0');
					}
					for (let i = 0; i < normal_temperature_body_imagecombo26.length; i++) {
						if ((normal_temperature_body_imagecombo26.length-normal_temperature_body_imagecombo26_current.length) < i && normal_temperature_body_imagecombo26_padding === false) {
							normal_temperature_body_imagecombo26[i].setProperty(hmUI.prop.VISIBLE, false);
						} else {
							normal_temperature_body_imagecombo26[i].setProperty(hmUI.prop.VISIBLE, true);
							normal_temperature_body_imagecombo26[i].setProperty(hmUI.prop.SRC, normal_temperature_body_imagecombo26_array[normal_temperature_body_imagecombo26_current.toString().charAt(i)]);
						}
					}
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				weatherSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateWeather();
				});

				body_tempSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateBodyTemp();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTime();
						updateWeather();
						updateBodyTemp();
						normal_user_region_text48.setProperty(hmUI.prop.TEXT, hmSetting.getUserData().region.toString().toUpperCase());
						normal_user_nickname_text49.setProperty(hmUI.prop.TEXT, hmSetting.getUserData().nickName.toString());
					}),
					pause_call: (function () {
						hmSetting.setBrightScreenCancel();
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
						hmSetting.setBrightScreenCancel();
		},
	});	})()
} catch (e) {
	console.log(e)
}