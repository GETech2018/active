﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'fundoZosilla2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 21,
              y: 400,
              src: 'redheart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 60,
              y: 391,
              font_array: ["zosillaMin0.png","zosillaMin1.png","zosillaMin2.png","zosillaMin3.png","zosillaMin4.png","zosillaMin5.png","zosillaMin6.png","zosillaMin7.png","zosillaMin8.png","zosillaMin9.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 397,
              src: 'bluesteps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 391,
              font_array: ["zosillaMin0.png","zosillaMin1.png","zosillaMin2.png","zosillaMin3.png","zosillaMin4.png","zosillaMin5.png","zosillaMin6.png","zosillaMin7.png","zosillaMin8.png","zosillaMin9.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 190,
              y: 57,
              src: 'reddot.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 12,
              y: 24,
              image_array: ["Weather_1.png","Weather_2.png","Weather_3.png","Weather_4.png","Weather_5.png","Weather_6.png","Weather_7.png","Weather_8.png","Weather_9.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 38,
              font_array: ["zosillaMin0.png","zosillaMin1.png","zosillaMin2.png","zosillaMin3.png","zosillaMin4.png","zosillaMin5.png","zosillaMin6.png","zosillaMin7.png","zosillaMin8.png","zosillaMin9.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 352,
              y: 40,
              src: 'battery2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 355,
              // start_y: 45,
              // color: 0xFF80FF80,
              // lenght: 37,
              // line_width: 16,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 248,
              y: 38,
              font_array: ["zosillaMin0.png","zosillaMin1.png","zosillaMin2.png","zosillaMin3.png","zosillaMin4.png","zosillaMin5.png","zosillaMin6.png","zosillaMin7.png","zosillaMin8.png","zosillaMin9.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 262,
              y: 123,
              week_en: ["zosillaSem01.png","zosillaSem02.png","zosillaSem03.png","zosillaSem04.png","zosillaSem05.png","zosillaSem06.png","zosillaSem07.png"],
              week_tc: ["zosillaSem01.png","zosillaSem02.png","zosillaSem03.png","zosillaSem04.png","zosillaSem05.png","zosillaSem06.png","zosillaSem07.png"],
              week_sc: ["zosillaSem01.png","zosillaSem02.png","zosillaSem03.png","zosillaSem04.png","zosillaSem05.png","zosillaSem06.png","zosillaSem07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 102,
              month_startY: 123,
              month_sc_array: ["zosillaMes01.png","zosillaMes02.png","zosillaMes03.png","zosillaMes04.png","zosillaMes05.png","zosillaMes06.png","zosillaMes07.png","zosillaMes08.png","zosillaMes09.png","zosillaMes10.png","zosillaMes11.png","zosillaMes12.png"],
              month_tc_array: ["zosillaMes01.png","zosillaMes02.png","zosillaMes03.png","zosillaMes04.png","zosillaMes05.png","zosillaMes06.png","zosillaMes07.png","zosillaMes08.png","zosillaMes09.png","zosillaMes10.png","zosillaMes11.png","zosillaMes12.png"],
              month_en_array: ["zosillaMes01.png","zosillaMes02.png","zosillaMes03.png","zosillaMes04.png","zosillaMes05.png","zosillaMes06.png","zosillaMes07.png","zosillaMes08.png","zosillaMes09.png","zosillaMes10.png","zosillaMes11.png","zosillaMes12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 14,
              day_startY: 123,
              day_sc_array: ["zosillaDia0.png","zosillaDia1.png","zosillaDia2.png","zosillaDia3.png","zosillaDia4.png","zosillaDia5.png","zosillaDia6.png","zosillaDia7.png","zosillaDia8.png","zosillaDia9.png"],
              day_tc_array: ["zosillaDia0.png","zosillaDia1.png","zosillaDia2.png","zosillaDia3.png","zosillaDia4.png","zosillaDia5.png","zosillaDia6.png","zosillaDia7.png","zosillaDia8.png","zosillaDia9.png"],
              day_en_array: ["zosillaDia0.png","zosillaDia1.png","zosillaDia2.png","zosillaDia3.png","zosillaDia4.png","zosillaDia5.png","zosillaDia6.png","zosillaDia7.png","zosillaDia8.png","zosillaDia9.png"],
              day_zero: 1,
              day_space: -5,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 7,
              hour_startY: 209,
              hour_array: ["zosillaBL0.png","zosillaBL1.png","zosillaBL2.png","zosillaBL3.png","zosillaBL4.png","zosillaBL5.png","zosillaBL6.png","zosillaBL7.png","zosillaBL8.png","zosillaBL9.png"],
              hour_zero: 1,
              hour_space: -8,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 208,
              minute_startY: 209,
              minute_array: ["zosillaBL0.png","zosillaBL1.png","zosillaBL2.png","zosillaBL3.png","zosillaBL4.png","zosillaBL5.png","zosillaBL6.png","zosillaBL7.png","zosillaBL8.png","zosillaBL9.png"],
              minute_zero: 1,
              minute_space: -8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 149,
              y: 194,
              src: 'zosillaBLdots.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 7,
              hour_startY: 209,
              hour_array: ["zosillaM0.png","zosillaM1.png","zosillaM2.png","zosillaM3.png","zosillaM4.png","zosillaM5.png","zosillaM6.png","zosillaM7.png","zosillaM8.png","zosillaM9.png"],
              hour_zero: 1,
              hour_space: -8,
              hour_angle: 0,
              // alpha: 175,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 208,
              minute_startY: 209,
              minute_array: ["zosillaM0.png","zosillaM1.png","zosillaM2.png","zosillaM3.png","zosillaM4.png","zosillaM5.png","zosillaM6.png","zosillaM7.png","zosillaM8.png","zosillaM9.png"],
              minute_zero: 1,
              minute_space: -8,
              minute_angle: 0,
              minute_follow: 0,
              // alpha: 175,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time.setAlpha(175);

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 149,
              y: 194,
              src: 'zosillaMdots.png',
              // alpha: 175,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img.setAlpha(175);
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 203,
              y: 390,
              w: 185,
              h: 60,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 390,
              w: 149,
              h: 60,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 18,
              w: 164,
              h: 79,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 355;
                  let start_y_normal_battery = 45;
                  let lenght_ls_normal_battery = 37;
                  let line_width_ls_normal_battery = 16;
                  let color_ls_normal_battery = 0xFF80FF80;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = line_width_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = lenght_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    line_width_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_y_normal_battery_draw = start_y_normal_battery_draw - line_width_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}