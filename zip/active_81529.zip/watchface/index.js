﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_date_week_font = new Array(7);
        let normal_forecast_date_week_font_Array = ['seg', 'ter', 'qua', 'qui', 'sex', 'sáb', 'dom'];
        let normal_forecast_average_text_font = new Array(7);
        let normal_canvas1 = '';
        let normal_canvas2 = '';
        let normal_forecast_image_progress_img_level = new Array(7);
        let normal_forecast_image_array = ['1069.png', '1070.png', '1071.png', '1072.png', '1073.png', '1074.png', '1075.png', '1076.png', '1077.png', '1078.png', '1079.png', '1080.png', '1081.png', '1082.png', '1083.png', '1084.png', '1085.png', '1086.png', '1087.png', '1088.png', '1089.png', '1090.png', '1091.png', '1092.png', '1093.png', '1094.png', '1095.png', '1096.png', '1097.png'];
        let normal_month_name_font = ''
        let normal_Month_Array = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez', ];
        let normal_day_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['seg', 'ter', 'qua', 'qui', 'sex', 'sáb', 'dom'];
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_battery_icon_img = ''
        let normal_battery_current_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_time_hour_min_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let idle_battery_current_text_font = ''
        let idle_time_hour_min_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let normal_step_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: WatchSNum-3R.ttf; FontSize: 150
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 1531,
              h: 154,
              text_size: 150,
              char_space: -6,
              line_space: 0,
              font: 'fonts/WatchSNum-3R.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: WatchSNum-3R.ttf; FontSize: 126
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 1435,
              h: 132,
              text_size: 126,
              char_space: 0,
              line_space: 0,
              font: 'fonts/WatchSNum-3R.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'fundoamaz.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 8,
              // y: 81,
              // ColumnWidth: 53,
              // DaysCount: 7,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 8,
              y: 81,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_forecast_date_week_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -48,
              // y: 290,
              // w: 152,
              // h: 27,
              // text_size: 18,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // color: 0xFFC0C0C0,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.TOP,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_date_week_img,
              // unit_string: seg,ter,qua,qui,sex,sáb,dom,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 7; i++) {
                normal_forecast_date_week_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -48 + i*53,
                  y: 290,
                  w: 152,
                  h: 27,
                  text_size: 18,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFC0C0C0,
                  // color_2: 0xFFFF0000,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_string: seg,ter,qua,qui,sex,sáb,dom,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_forecast_average_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -53,
              // y: 235,
              // w: 167,
              // h: 28,
              // text_size: 22,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // color: 0xFFFFFFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.TOP,
              // text_style: hmUI.text_style.WRAP,
              // type: hmUI.data_type.forecast_average_text_font,
              // unit_type: 1,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 7; i++) {
                normal_forecast_average_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -53 + i*53,
                  y: 235,
                  w: 167,
                  h: 28,
                  text_size: 22,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFFFFFFF,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.WRAP,
                  // unit_type: 1,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block
            
            //start of ignored block
            function drawLine(canvas1, canvas2, x1, y1, x2, y2, color, line_width) {
              if (x1 > x2) {
                let temp_x = x1;
                let temp_y = y1;
                x1 = x2;
                y1 = y2;
                x2 = temp_x;
                y2 = temp_y;
              };
              
              if (x1 < 215) {
                canvas1.setPaint({ color: color, line_width: line_width });
                canvas1.drawLine({ x1: x1, y1: y1, x2: x2, y2: y2 });
              };
              if (x2 >= 215) {
                canvas2.setPaint({ color: color, line_width: line_width });
                canvas2.drawLine({ x1: x1-215, y1: y1, x2: x2-215, y2: y2 });
              }
            };
            
            function drawRect(canvas1, canvas2, x1, y1, x2, y2, color) {
              if (x1 > x2) {
                let temp_x = x1;
                let temp_y = y1;
                x1 = x2;
                y1 = y2;
                x2 = temp_x;
                y2 = temp_y;
              };
              
              if (x1 < 215) {
                canvas1.drawRect({ x1: x1, y1: y1, x2: x2, y2: y2, color: color });
              };
              if (x2 >= 215) {
                canvas2.drawRect({ x1: x1-215, y1: y1, x2: x2-215, y2: y2, color: color });
              }
            };
            
            function drawCircle(canvas1, canvas2, center_x, center_y, color, radius) {
              if (center_x < 215+radius) {
                canvas1.drawCircle({ center_x: center_x, center_y: center_y, radius: radius, color: color });
              };
              if (center_x >= 215-radius) {
                canvas2.drawCircle({ center_x: center_x-215, center_y: center_y, radius: radius, color: color });
              }
            };
            
            function drawGraphPoint(canvas1, canvas2, x, y, color, pointSize, pointType) {
              switch (pointType) {
                case 1:
                  x -= pointSize/2;
                  y -= pointSize/2;
                  drawRect(canvas1, canvas2, x, y, x+pointSize, y+pointSize, color);
                  break;
                case 2:
                  let posX = x - pointSize/2;
                  let posY = y - pointSize/2;
                  drawRect(canvas1, canvas2, posX, posY, posX+pointSize, posY+pointSize, color );
                  posX = x - pointSize/4;
                  posY = y - pointSize/4;
                  drawRect(canvas1, canvas2, posX, posY, posX+pointSize/2, posY+pointSize/2, 0xffffff );
                  break;
                case 3:
                  drawCircle(canvas1, canvas2, x, y, color, pointSize/2 );
                  break;
                case 4:
                  drawCircle(canvas1, canvas2, x, y, color, pointSize/2 );
                  drawCircle(canvas1, canvas2, x, y, 0xffffff, pointSize/4 );
                  break;
              }
            };

            //end of ignored block
            

            //start of ignored block
            function graphScale(heightGraph, maxPointSize, minPointSize, forecastData, daysCount) {
              console.log(`function graphScale`);
              heightGraph -= (maxPointSize + minPointSize) / 2;
              let high = -300;
              let low = 300;
              for (let index = 0; index < daysCount; index++) {
                if (index < forecastData.length) {
                  let item = forecastData[index];
                  if (item.high > high) high = item.high;;
                  if (item.low < low) low = item.low; ;
                } // end if
              } // end for
              let delta = high - low;
              let scale = heightGraph / delta;
              console.log(`heightGraph: ${heightGraph}; high: ${high}; low : ${low}`);
              return {graphScale: scale, maximal_temp: high};
            };

            //end of ignored block

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              normal_canvas1 = normal_group_ForecastWeather.createWidget(hmUI.widget.CANVAS, {
                x: -4,
                y: 165,
                w: 215,
                h: 215,
              });

              normal_canvas2 = normal_group_ForecastWeather.createWidget(hmUI.widget.CANVAS, {
                x: 211,
                y: 165,
                w: 215,
                h: 215,
              });
            };
            //end of ignored block

            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 10,
              // y: 265,
              // image_array: ["1069.png","1070.png","1071.png","1072.png","1073.png","1074.png","1075.png","1076.png","1077.png","1078.png","1079.png","1080.png","1081.png","1082.png","1083.png","1084.png","1085.png","1086.png","1087.png","1088.png","1089.png","1090.png","1091.png","1092.png","1093.png","1094.png","1095.png","1096.png","1097.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 7; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 10 + i*53,
                  y: 265,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 225,
              y: 154,
              w: 150,
              h: 33,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: jan,fev,mar,abr,mai,jun,jul,ago,set,out,nov,dez,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 176,
              y: 154,
              w: 38,
              h: 30,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 75,
              y: 149,
              w: 89,
              h: 36,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: seg,ter,qua,qui,sex,sáb,dom,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 95,
              y: 413,
              src: '0062.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 117,
              y: 410,
              w: 156,
              h: 35,
              text_size: 36,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 129,
              y: 1,
              src: '0061.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 120,
              y: 1,
              w: 150,
              h: 32,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFF00FF40,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 122,
              y: 177,
              image_array: ["0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png"],
              image_length: 29,
              shortcut: true,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 76,
              y: 209,
              w: 70,
              h: 25,
              text_size: 21,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 75,
              y: 228,
              w: 70,
              h: 25,
              text_size: 21,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 238,
              y: 216,
              w: 89,
              h: 32,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 10,
              y: 42,
              w: 370,
              h: 114,
              text_size: 150,
              char_space: -6,
              line_space: 0,
              font: 'fonts/WatchSNum-3R.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 120,
              y: 400,
              w: 150,
              h: 40,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 28,
              y: 90,
              w: 334,
              h: 120,
              text_size: 126,
              char_space: 0,
              line_space: 0,
              font: 'fonts/WatchSNum-3R.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 118,
              y: 404,
              w: 159,
              h: 42,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 116,
              y: 0,
              w: 154,
              h: 43,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 226,
              w: 296,
              h: 154,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 64,
              w: 298,
              h: 139,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            //start of ignored block
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
              let result = {graphScale: 1, maximal_temp: 0};
              let averageOldX = 0;

              if (screenType == hmSetting.screen_type.WATCHFACE) result = graphScale(84, 0, 0, forecastData.data, 7);
              let forecastGraphScale = result.graphScale;
              let maximal_temp = result.maximal_temp;
              console.log(`forecastGraphScale = ${forecastGraphScale}, maximal_temp = ${maximal_temp}`);

              if (screenType == hmSetting.screen_type.WATCHFACE) {
                normal_canvas2.clear({x: 0, y:0, w: 215, h: 215});
              };
              let normal_average_offsetX = 31;
              if (screenType == hmSetting.screen_type.WATCHFACE) averageOldX = normal_average_offsetX;
              let averageOldY = (maximal_temp - (forecastData.data[0].high + forecastData.data[0].low) / 2) * forecastGraphScale + 0;
              let endPointAverage = false;
              for (let i = 0; i < 7; i++) {
                // DayOfWeek font
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_font[i].setProperty(hmUI.prop.TEXT, normal_forecast_date_week_font_Array[dowIndex]);
                };
              
                // Number_Font_Average
                let averageTemperature = '-';
                if (i < forecastData.count) averageTemperature = parseInt((forecastData.data[i].high + forecastData.data[i].low)/2).toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_average_text_font[i].setProperty(hmUI.prop.TEXT, averageTemperature + '°');
                };
                
                // Graph
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (i < forecastData.count) {
                    let averageStartX = averageOldX;
                    let averageStartY = averageOldY;
                    averageOldX = normal_average_offsetX + i * 53;
                    averageOldY = (maximal_temp - (forecastData.data[i].high + forecastData.data[i].low) / 2) * forecastGraphScale + 0;
                    let averageEndX = averageOldX;
                    let averageEndY = averageOldY;
                    if (averageStartX != averageEndX) {
                      drawLine(normal_canvas1, normal_canvas2, averageStartX, averageStartY, averageEndX, averageEndY, 0xFF6F0000, 7)
                      drawGraphPoint(normal_canvas1, normal_canvas2, averageStartX, averageStartY, 0xFF6F0000, 8, 4)
                      endPointAverage = true;
                    };
                  
                  };
                };  // end screen_type
                
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

              if (screenType == hmSetting.screen_type.WATCHFACE && endPointAverage) {
                drawGraphPoint(normal_canvas1, normal_canvas2, averageOldX, averageOldY, 0xFF6F0000, 8, 4)
              };
            };
            //end of ignored block

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('hour:min font');
              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) normal_HourMinStr = 'pm ' + normal_HourMinStr
                  else normal_HourMinStr = 'am ' + normal_HourMinStr
                };
                normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };

              console.log('hour:min font');
              if (updateMinute) {
                let idle_HourMinStr = format_hour.toString();
                idle_HourMinStr = idle_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) idle_HourMinStr = 'pm ' + idle_HourMinStr
                  else idle_HourMinStr = 'am ' + idle_HourMinStr
                };
                idle_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinStr );
              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                weather_few_days();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}