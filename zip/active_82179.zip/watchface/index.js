﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_stress_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_target_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_year = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let Button_1 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'active_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 262,
              y: 406,
              font_array: ["sun_number-0.png","sun_number-1.png","sun_number-2.png","sun_number-3.png","sun_number-4.png","sun_number-5.png","sun_number-6.png","sun_number-7.png","sun_number-8.png","sun_number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 136,
              y: 406,
              font_array: ["sun_number-0.png","sun_number-1.png","sun_number-2.png","sun_number-3.png","sun_number-4.png","sun_number-5.png","sun_number-6.png","sun_number-7.png","sun_number-8.png","sun_number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 246,
              y: 349,
              font_array: ["upper_number-0.png","upper_number-1.png","upper_number-2.png","upper_number-3.png","upper_number-4.png","upper_number-5.png","upper_number-6.png","upper_number-7.png","upper_number-8.png","upper_number-9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 67,
              y: 350,
              font_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 186,
              y: 375,
              image_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png"],
              image_length: 14,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 245,
              w: 230,
              h: 36,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFFD9D9D9,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 20,
              y: 250,
              image_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 294,
              font_array: ["upper_number-0.png","upper_number-1.png","upper_number-2.png","upper_number-3.png","upper_number-4.png","upper_number-5.png","upper_number-6.png","upper_number-7.png","upper_number-8.png","upper_number-9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'upper_number-degree.png',
              unit_tc: 'upper_number-degree.png',
              unit_en: 'upper_number-degree.png',
              imperial_unit_sc: 'upper_number-degree.png',
              imperial_unit_tc: 'upper_number-degree.png',
              imperial_unit_en: 'upper_number-degree.png',
              negative_image: 'upper_number-minus.png',
              invalid_image: 'upper_number-null.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_high_text_img.setProperty(hmUI.prop.MORE, {
                x: 325,
                y: 294,
                font_array: ["upper_number-0.png","upper_number-1.png","upper_number-2.png","upper_number-3.png","upper_number-4.png","upper_number-5.png","upper_number-6.png","upper_number-7.png","upper_number-8.png","upper_number-9.png"],
                padding: false,
                h_space: 1,
                unit_sc: 'upper_number-degree.png',
                unit_tc: 'upper_number-degree.png',
                unit_en: 'upper_number-degree.png',
                imperial_unit_sc: 'upper_number-degree.png',
                imperial_unit_tc: 'upper_number-degree.png',
                imperial_unit_en: 'upper_number-degree.png',
                negative_image: 'upper_number-minus.png',
                invalid_image: 'upper_number-null.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.WEATHER_HIGH,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 238,
              y: 294,
              font_array: ["upper_number-0.png","upper_number-1.png","upper_number-2.png","upper_number-3.png","upper_number-4.png","upper_number-5.png","upper_number-6.png","upper_number-7.png","upper_number-8.png","upper_number-9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'upper_number-degree.png',
              unit_tc: 'upper_number-degree.png',
              unit_en: 'upper_number-degree.png',
              imperial_unit_sc: 'upper_number-degree.png',
              imperial_unit_tc: 'upper_number-degree.png',
              imperial_unit_en: 'upper_number-degree.png',
              negative_image: 'upper_number-dash.png',
              invalid_image: 'upper_number-null.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_low_text_img.setProperty(hmUI.prop.MORE, {
                x: 238,
                y: 294,
                font_array: ["upper_number-0.png","upper_number-1.png","upper_number-2.png","upper_number-3.png","upper_number-4.png","upper_number-5.png","upper_number-6.png","upper_number-7.png","upper_number-8.png","upper_number-9.png"],
                padding: false,
                h_space: 1,
                unit_sc: 'upper_number-degree.png',
                unit_tc: 'upper_number-degree.png',
                unit_en: 'upper_number-degree.png',
                imperial_unit_sc: 'upper_number-degree.png',
                imperial_unit_tc: 'upper_number-degree.png',
                imperial_unit_en: 'upper_number-degree.png',
                negative_image: 'upper_number-dash.png',
                invalid_image: 'upper_number-null.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.WEATHER_LOW,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 123,
              y: 290,
              font_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'date-degree.png',
              unit_tc: 'date-degree.png',
              unit_en: 'date-degree.png',
              imperial_unit_sc: 'date-degree.png',
              imperial_unit_tc: 'date-degree.png',
              imperial_unit_en: 'date-degree.png',
              negative_image: 'date-minus.png',
              invalid_image: 'date-null.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 123,
                y: 290,
                font_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
                padding: false,
                h_space: 1,
                unit_sc: 'date-degree.png',
                unit_tc: 'date-degree.png',
                unit_en: 'date-degree.png',
                imperial_unit_sc: 'date-degree.png',
                imperial_unit_tc: 'date-degree.png',
                imperial_unit_en: 'date-degree.png',
                negative_image: 'date-minus.png',
                invalid_image: 'date-null.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 1,
              hour_startY: 131,
              hour_array: ["time-0.png","time-1.png","time-2.png","time-3.png","time-4.png","time-5.png","time-6.png","time-7.png","time-8.png","time-9.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_unit_sc: 'time-dot.png',
              hour_unit_tc: 'time-dot.png',
              hour_unit_en: 'time-dot.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["time-0.png","time-1.png","time-2.png","time-3.png","time-4.png","time-5.png","time-6.png","time-7.png","time-8.png","time-9.png"],
              minute_zero: 1,
              minute_space: -3,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: 'second-dot.png',
              minute_unit_tc: 'second-dot.png',
              minute_unit_en: 'second-dot.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 0,
              second_startY: 0,
              second_array: ["second-0.png","second-1.png","second-2.png","second-3.png","second-4.png","second-5.png","second-6.png","second-7.png","second-8.png","second-9.png"],
              second_zero: 1,
              second_space: -3,
              second_angle: 0,
              second_follow: 1,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 233,
              y: 67,
              w: 143,
              h: 42,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              color: 0xFFE6E6E6,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 179,
              day_startY: 75,
              day_sc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              day_tc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              day_en_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 118,
              month_startY: 75,
              month_sc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              month_tc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              month_en_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              month_zero: 0,
              month_space: 2,
              month_unit_sc: 'date-slash.png',
              month_unit_tc: 'date-slash.png',
              month_unit_en: 'date-slash.png',
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 24,
              year_startY: 75,
              year_sc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              year_tc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              year_en_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              year_zero: 1,
              year_space: 1,
              year_unit_sc: 'date-slash.png',
              year_unit_tc: 'date-slash.png',
              year_unit_en: 'date-slash.png',
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 274,
              y: 19,
              font_array: ["bottom_number-0.png","bottom_number-1.png","bottom_number-2.png","bottom_number-3.png","bottom_number-4.png","bottom_number-5.png","bottom_number-6.png","bottom_number-7.png","bottom_number-8.png","bottom_number-9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'bottom_number-b.png',
              unit_tc: 'bottom_number-b.png',
              unit_en: 'bottom_number-b.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 214,
              y: 24,
              image_array: ["147.png","148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 138,
              y: 21,
              src: 'icon-lock-3-s.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 67,
              y: 20,
              src: 'bluetooth-NG-7.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 102,
              y: 21,
              src: '174.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 57,
              hour_startY: 173,
              hour_array: ["second-0.png","second-1.png","second-2.png","second-3.png","second-4.png","second-5.png","second-6.png","second-7.png","second-8.png","second-9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_unit_sc: 'second-dot.png',
              hour_unit_tc: 'second-dot.png',
              hour_unit_en: 'second-dot.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["second-0.png","second-1.png","second-2.png","second-3.png","second-4.png","second-5.png","second-6.png","second-7.png","second-8.png","second-9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 337,
              w: 390,
              h: 59,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 242,
              w: 390,
              h: 94,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 126,
              y: 121,
              w: 135,
              h: 119,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 263,
              y: 121,
              w: 127,
              h: 119,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 121,
              w: 124,
              h: 119,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 397,
              w: 390,
              h: 54,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 63,
              w: 390,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'toumei_transparent.png',
              normal_src: 'toumei_transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}