﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_current_text_font = ''
        let normal_battery_icon_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_current_text_font = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_font = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_year_text_font = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SEP', 'OCT', 'NOV', 'DIC', ];
        let normal_day_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_moon_image_progress_img_level = ''
        let normal_wind_icon_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_current_text_font = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_current_text_font = ''
        let normal_sun_icon_img = ''
        let normal_sun_low_text_font = ''
        let normal_sun_high_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_icon_img = ''
        let normal_system_clock_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let idle_background_bg_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_current_text_font = ''
        let idle_year_text_font = ''
        let idle_month_name_font = ''
        let idle_Month_Array = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SEP', 'OCT', 'NOV', 'DIC', ];
        let idle_day_text_font = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_system_clock_img = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_readiness_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: RCAM_UNISANBAS.ttf; FontSize: 35; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 42,
              h: 42,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFF66CF18,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: RCAM_UNISANBAS.ttf; FontSize: 50
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 630,
              h: 68,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFF00FFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: RCAM_UNISANBAS.ttf; FontSize: 50; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 60,
              h: 60,
              text_size: 50,
              char_space: -2,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFF91CDFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: RCAM_UNISANBAS.ttf; FontSize: 33
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 421,
              h: 49,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFF8080FF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: RCAM_UNISANBAS.ttf; FontSize: 30; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 36,
              h: 36,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFFFFFF00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: RCAM_UNISANBAS.ttf; FontSize: 27
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 344,
              h: 40,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFF64B1FF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: RCAM_UNISANBAS.ttf; FontSize: 36
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 451,
              h: 54,
              text_size: 36,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFFFFFF00,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'FONDO_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 190,
              y: 417,
              src: 'I_DISTANCIA.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 218,
              y: 417,
              w: 150,
              h: 35,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFF66CF18,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 417,
              src: 'BAT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 97,
              // start_y: 420,
              // color: 0xFF000000,
              // lenght: -38,
              // line_width: 21,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 104,
              y: 417,
              w: 150,
              h: 35,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFFFFFF00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 262,
              y: 371,
              src: 'I_PASOS.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 291,
              y: 371,
              w: 150,
              h: 35,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFF357BFD,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 105,
              y: 371,
              src: 'I_CAL.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 133,
              y: 371,
              w: 125,
              h: 35,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFFFF8000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 5,
              y: 371,
              src: 'I_CARDIO.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 36,
              y: 371,
              w: 64,
              h: 35,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFFFF0000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_year_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 282,
              y: 316,
              w: 112,
              h: 50,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFF00FFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 167,
              y: 316,
              w: 120,
              h: 50,
              text_size: 50,
              char_space: -2,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFF91CDFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ENE, FEB, MAR, ABR, MAY, JUN, JUL, AGO, SEP, OCT, NOV, DIC,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 104,
              y: 316,
              w: 70,
              h: 50,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFF00FFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 316,
              w: 113,
              h: 50,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFF7BC6FD,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: Lun, Mar, Mié, Jue, Vie, Sáb, Dom,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 0,
              hour_startY: 192,
              hour_array: ["T000.png","T001.png","T002.png","T003.png","T004.png","T005.png","T006.png","T007.png","T008.png","T009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 212,
              minute_startY: 192,
              minute_array: ["T000.png","T001.png","T002.png","T003.png","T004.png","T005.png","T006.png","T007.png","T008.png","T009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 178,
              y: 192,
              src: 'SEP.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 178,
              am_y: 191,
              am_sc_path: 'SEP_AM_30.png',
              am_en_path: 'SEP_AM_30.png',
              pm_x: 178,
              pm_y: 191,
              pm_sc_path: 'SEP_PM_30.png',
              pm_en_path: 'SEP_PM_30.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 318,
              y: 97,
              image_array: ["L_01.png","L_02.png","L_03.png","L_04.png","L_05.png","L_06.png","L_07.png","L_08.png","L_09.png","L_10.png","L_11.png","L_12.png","L_13.png","L_14.png","L_15.png","L_16.png","L_17.png","L_18.png","L_19.png","L_20.png","L_21.png","L_22.png","L_23.png","L_24.png","L_25.png","L_26.png","L_27.png","L_28.png","L_29.png","L_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 6,
              y: 114,
              src: 'I_VEL.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 46,
              y: 113,
              image_array: ["DV_1.png","DV_2.png","DV_3.png","DV_4.png","DV_5.png","DV_6.png","DV_7.png","DV_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 9,
              y: 152,
              w: 32,
              h: 32,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFF8080FF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 305,
              y: 49,
              src: 'I_HUM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 329,
              y: 51,
              w: 73,
              h: 32,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFF2492FF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 3,
              y: 41,
              src: 'I_AMAATA.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 41,
              y: 77,
              w: 86,
              h: 32,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFFFB5200,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 40,
              y: 45,
              w: 86,
              h: 32,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFFFF8000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 121,
              y: 42,
              image_array: ["CLIMA_00.png","CLIMA_01.png","CLIMA_02.png","CLIMA_03.png","CLIMA_04.png","CLIMA_05.png","CLIMA_06.png","CLIMA_07.png","CLIMA_08.png","CLIMA_09.png","CLIMA_10.png","CLIMA_11.png","CLIMA_12.png","CLIMA_13.png","CLIMA_14.png","CLIMA_15.png","CLIMA_16.png","CLIMA_17.png","CLIMA_18.png","CLIMA_19.png","CLIMA_20.png","CLIMA_21.png","CLIMA_22.png","CLIMA_23.png","CLIMA_24.png","CLIMA_25.png","CLIMA_26.png","CLIMA_27.png","CLIMA_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 122,
              y: 38,
              w: 219,
              h: 35,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFFFFFF00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 224,
              y: 138,
              w: 60,
              h: 27,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFF64B1FF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.BOTTOM,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 228,
              y: 99,
              w: 68,
              h: 36,
              text_size: 36,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFFFFFF00,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.BOTTOM,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 224,
              y: 67,
              w: 60,
              h: 27,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFFFF0000,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.BOTTOM,
              unit_type: 1,
              text_style: hmUI.text_style.WRAP,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 63,
              src: 'I_TEMP.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 88,
              y: 3,
              src: 'I_ALA.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 57,
              y: 3,
              src: 'I_BLO.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 273,
              y: 3,
              src: 'I_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 307,
              y: 3,
              src: 'I_BLU_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'FONDO_AOD_N.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 417,
              src: 'BAT.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 97,
              // start_y: 420,
              // color: 0xFF000000,
              // lenght: -38,
              // line_width: 21,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 104,
              y: 417,
              w: 150,
              h: 35,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFFFFFF00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.BOTTOM,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_year_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 282,
              y: 316,
              w: 112,
              h: 50,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFF00FFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 167,
              y: 316,
              w: 120,
              h: 50,
              text_size: 50,
              char_space: -2,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFF91CDFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ENE, FEB, MAR, ABR, MAY, JUN, JUL, AGO, SEP, OCT, NOV, DIC,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 104,
              y: 316,
              w: 70,
              h: 50,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFF00FFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 316,
              w: 113,
              h: 50,
              text_size: 50,
              char_space: -2,
              line_space: 0,
              font: 'fonts/RCAM_UNISANBAS.ttf',
              color: 0xFF7BC6FD,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: Lun, Mar, Mié, Jue, Vie, Sáb, Dom,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 0,
              hour_startY: 192,
              hour_array: ["T000.png","T001.png","T002.png","T003.png","T004.png","T005.png","T006.png","T007.png","T008.png","T009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 212,
              minute_startY: 192,
              minute_array: ["T000.png","T001.png","T002.png","T003.png","T004.png","T005.png","T006.png","T007.png","T008.png","T009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 178,
              y: 192,
              src: 'SEP.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 178,
              am_y: 191,
              am_sc_path: 'SEP_AM_30.png',
              am_en_path: 'SEP_AM_30.png',
              pm_x: 178,
              pm_y: 191,
              pm_sc_path: 'SEP_PM_30.png',
              pm_en_path: 'SEP_PM_30.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 88,
              y: 3,
              src: 'I_ALA.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 57,
              y: 3,
              src: 'I_BLO.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 273,
              y: 3,
              src: 'I_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 307,
              y: 3,
              src: 'I_BLU_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Conexión perdida,
              // conneсnt_vibrate_type: 25,
              // conneсnt_toast_text: Conexión recuperada,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Conexión perdida"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Conexión recuperada"});
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 266,
              y: 366,
              w: 106,
              h: 38,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 9,
              y: 366,
              w: 86,
              h: 38,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 49,
              y: 412,
              w: 122,
              h: 34,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 7,
              y: 41,
              w: 105,
              h: 66,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 137,
              y: 66,
              w: 106,
              h: 100,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 224,
              y: 197,
              w: 158,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 6,
              y: 198,
              w: 162,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 318,
              y: 95,
              w: 70,
              h: 83,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 413,
              w: 147,
              h: 34,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 107,
              y: 366,
              w: 142,
              h: 38,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('year font');
              if (updateHour) {
                let normal_yearStr = timeSensor.year.toString();
                normal_year_text_font.setProperty(hmUI.prop.TEXT, normal_yearStr );
              };

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('year font');
              if (updateHour) {
                let idle_yearStr = timeSensor.year.toString();
                idle_year_text_font.setProperty(hmUI.prop.TEXT, idle_yearStr );
              };

              console.log('month font');
              if (updateHour) {
                let idle_Month_Str = idle_Month_Array[timeSensor.month-1];
                idle_month_name_font.setProperty(hmUI.prop.TEXT, idle_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 59;
                  let start_y_normal_battery = 420;
                  let lenght_ls_normal_battery = 38;
                  let line_width_ls_normal_battery = 21;
                  let color_ls_normal_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 59;
                  let start_y_idle_battery = 420;
                  let lenght_ls_idle_battery = 38;
                  let line_width_ls_idle_battery = 21;
                  let color_ls_idle_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}